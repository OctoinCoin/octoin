#include "../../src/designer/src/lib/sdk/abstractresourcebrowser.h"
