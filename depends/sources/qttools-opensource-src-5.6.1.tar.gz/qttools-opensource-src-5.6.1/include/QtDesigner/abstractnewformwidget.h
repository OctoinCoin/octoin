#include "../../src/designer/src/lib/sdk/abstractnewformwidget.h"
