#include "../../src/designer/src/lib/sdk/abstractformwindowcursor.h"
