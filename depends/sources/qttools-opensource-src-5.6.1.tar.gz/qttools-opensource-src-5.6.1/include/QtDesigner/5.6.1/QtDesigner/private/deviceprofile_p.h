#include "../../../../../src/designer/src/lib/shared/deviceprofile_p.h"
