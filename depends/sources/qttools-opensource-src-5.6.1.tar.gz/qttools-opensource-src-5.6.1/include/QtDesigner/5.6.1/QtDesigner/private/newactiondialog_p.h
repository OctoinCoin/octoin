#include "../../../../../src/designer/src/lib/shared/newactiondialog_p.h"
