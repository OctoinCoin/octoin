#include "../../../../../src/designer/src/lib/shared/qdesigner_dnditem_p.h"
