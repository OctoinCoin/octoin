#include "../../../../../src/designer/src/lib/shared/previewconfigurationwidget_p.h"
