#include "../../../../../src/designer/src/lib/shared/qdesigner_qsettings_p.h"
