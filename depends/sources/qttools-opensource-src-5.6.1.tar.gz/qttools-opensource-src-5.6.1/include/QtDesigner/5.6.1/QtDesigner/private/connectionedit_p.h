#include "../../../../../src/designer/src/lib/shared/connectionedit_p.h"
