#include "../../../../../src/designer/src/lib/shared/promotionmodel_p.h"
