#include "../../../../../src/designer/src/lib/shared/qtresourceeditordialog_p.h"
