#include "../../../../../src/designer/src/lib/shared/newformwidget_p.h"
