#include "../../../../../src/designer/src/lib/shared/qdesigner_dockwidget_p.h"
