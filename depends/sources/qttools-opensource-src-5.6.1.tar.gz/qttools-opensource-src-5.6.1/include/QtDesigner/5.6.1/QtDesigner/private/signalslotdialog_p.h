#include "../../../../../src/designer/src/lib/shared/signalslotdialog_p.h"
