#include "../../../../../src/designer/src/lib/shared/qsimpleresource_p.h"
