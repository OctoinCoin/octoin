#include "../../../../../src/designer/src/lib/shared/qtresourcemodel_p.h"
