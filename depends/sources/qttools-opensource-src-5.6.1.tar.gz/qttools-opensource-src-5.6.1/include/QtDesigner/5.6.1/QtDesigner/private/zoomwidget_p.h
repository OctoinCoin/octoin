#include "../../../../../src/designer/src/lib/shared/zoomwidget_p.h"
