#include "../../src/designer/src/lib/sdk/abstractformeditorplugin.h"
