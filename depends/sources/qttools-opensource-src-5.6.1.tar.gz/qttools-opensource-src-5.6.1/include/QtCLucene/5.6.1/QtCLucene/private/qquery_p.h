#include "../../../../../src/assistant/clucene/qquery_p.h"
