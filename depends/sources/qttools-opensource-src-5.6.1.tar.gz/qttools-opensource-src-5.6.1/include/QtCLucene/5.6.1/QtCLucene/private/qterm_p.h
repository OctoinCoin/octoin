#include "../../../../../src/assistant/clucene/qterm_p.h"
