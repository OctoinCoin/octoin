#include "../../../../../src/assistant/clucene/qdocument_p.h"
