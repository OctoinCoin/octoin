#include "../../../../../src/assistant/clucene/qclucene_global_p.h"
