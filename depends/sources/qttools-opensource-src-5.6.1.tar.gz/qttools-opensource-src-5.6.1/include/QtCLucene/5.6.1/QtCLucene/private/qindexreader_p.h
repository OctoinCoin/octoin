#include "../../../../../src/assistant/clucene/qindexreader_p.h"
