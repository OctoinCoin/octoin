#include "../../../../../src/assistant/clucene/qindexwriter_p.h"
