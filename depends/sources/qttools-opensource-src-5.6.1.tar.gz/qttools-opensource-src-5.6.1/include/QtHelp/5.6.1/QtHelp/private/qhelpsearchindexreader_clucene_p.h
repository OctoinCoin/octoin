#include "../../../../../src/assistant/help/qhelpsearchindexreader_clucene_p.h"
