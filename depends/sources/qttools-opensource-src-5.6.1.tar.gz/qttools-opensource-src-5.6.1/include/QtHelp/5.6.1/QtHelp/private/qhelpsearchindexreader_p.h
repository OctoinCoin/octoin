#include "../../../../../src/assistant/help/qhelpsearchindexreader_p.h"
