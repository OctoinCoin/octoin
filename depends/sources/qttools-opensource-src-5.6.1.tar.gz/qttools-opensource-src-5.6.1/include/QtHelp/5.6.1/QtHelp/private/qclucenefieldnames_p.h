#include "../../../../../src/assistant/help/qclucenefieldnames_p.h"
