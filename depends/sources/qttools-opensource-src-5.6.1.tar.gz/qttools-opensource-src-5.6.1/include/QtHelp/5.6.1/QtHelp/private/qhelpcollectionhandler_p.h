#include "../../../../../src/assistant/help/qhelpcollectionhandler_p.h"
