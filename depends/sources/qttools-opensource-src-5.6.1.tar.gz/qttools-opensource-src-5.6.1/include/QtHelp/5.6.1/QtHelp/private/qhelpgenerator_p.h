#include "../../../../../src/assistant/help/qhelpgenerator_p.h"
