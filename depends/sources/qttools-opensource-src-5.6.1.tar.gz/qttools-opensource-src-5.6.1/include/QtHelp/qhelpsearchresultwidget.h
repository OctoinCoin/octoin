#include "../../src/assistant/help/qhelpsearchresultwidget.h"
