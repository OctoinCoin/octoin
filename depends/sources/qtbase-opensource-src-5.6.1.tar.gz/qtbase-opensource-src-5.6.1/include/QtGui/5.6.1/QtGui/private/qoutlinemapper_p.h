#include "../../../../../src/gui/painting/qoutlinemapper_p.h"
