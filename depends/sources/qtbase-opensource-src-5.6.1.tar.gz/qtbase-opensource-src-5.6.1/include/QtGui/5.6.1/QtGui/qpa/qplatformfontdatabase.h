#include "../../../../../src/gui/text/qplatformfontdatabase.h"
