#include "../../../../../src/gui/kernel/qplatformcursor.h"
