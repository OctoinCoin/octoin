#include "../../../../../src/gui/kernel/qplatformsystemtrayicon.h"
