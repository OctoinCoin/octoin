#include "../../../../../src/gui/painting/qcosmeticstroker_p.h"
