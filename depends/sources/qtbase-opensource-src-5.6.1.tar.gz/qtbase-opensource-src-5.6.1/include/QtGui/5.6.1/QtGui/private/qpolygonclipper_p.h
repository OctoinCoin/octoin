#include "../../../../../src/gui/painting/qpolygonclipper_p.h"
