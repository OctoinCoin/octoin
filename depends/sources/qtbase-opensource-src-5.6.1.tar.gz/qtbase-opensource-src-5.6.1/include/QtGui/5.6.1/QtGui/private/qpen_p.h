#include "../../../../../src/gui/painting/qpen_p.h"
