#include "../../../../../src/gui/painting/qdrawhelper_p.h"
