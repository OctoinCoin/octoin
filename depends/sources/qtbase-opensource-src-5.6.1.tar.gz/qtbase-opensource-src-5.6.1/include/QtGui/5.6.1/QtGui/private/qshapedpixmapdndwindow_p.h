#include "../../../../../src/gui/kernel/qshapedpixmapdndwindow_p.h"
