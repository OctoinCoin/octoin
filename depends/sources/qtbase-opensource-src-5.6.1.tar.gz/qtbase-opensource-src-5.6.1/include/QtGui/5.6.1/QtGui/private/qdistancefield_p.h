#include "../../../../../src/gui/text/qdistancefield_p.h"
