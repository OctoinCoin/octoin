#include "../../../../../src/gui/kernel/qplatformclipboard.h"
