#include "../../../../../src/gui/painting/qmemrotate_p.h"
