#include "../../../../../src/gui/kernel/qsessionmanager_p.h"
