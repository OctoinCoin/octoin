#include "../../../../../src/gui/painting/qpathsimplifier_p.h"
