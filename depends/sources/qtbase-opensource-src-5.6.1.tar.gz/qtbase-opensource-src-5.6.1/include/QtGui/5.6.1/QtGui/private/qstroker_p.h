#include "../../../../../src/gui/painting/qstroker_p.h"
