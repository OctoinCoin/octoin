#include "../../../../../src/gui/painting/qimagescale_p.h"
