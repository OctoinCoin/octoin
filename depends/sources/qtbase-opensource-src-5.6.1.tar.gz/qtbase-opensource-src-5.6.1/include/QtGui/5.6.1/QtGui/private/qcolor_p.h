#include "../../../../../src/gui/painting/qcolor_p.h"
