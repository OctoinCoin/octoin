#include "../../../../../src/gui/painting/qpainterpath_p.h"
