#include "../../../../../src/gui/kernel/qplatformsharedgraphicscache.h"
