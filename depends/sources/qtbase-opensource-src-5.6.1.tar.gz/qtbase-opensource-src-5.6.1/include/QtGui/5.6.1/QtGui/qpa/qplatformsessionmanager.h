#include "../../../../../src/gui/kernel/qplatformsessionmanager.h"
