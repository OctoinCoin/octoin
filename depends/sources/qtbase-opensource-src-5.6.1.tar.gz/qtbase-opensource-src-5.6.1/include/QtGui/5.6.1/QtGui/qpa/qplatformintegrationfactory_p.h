#include "../../../../../src/gui/kernel/qplatformintegrationfactory_p.h"
