#include "../../../../../src/gui/image/qicon_p.h"
