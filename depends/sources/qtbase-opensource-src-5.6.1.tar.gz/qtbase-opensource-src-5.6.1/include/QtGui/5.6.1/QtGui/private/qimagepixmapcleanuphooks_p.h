#include "../../../../../src/gui/image/qimagepixmapcleanuphooks_p.h"
