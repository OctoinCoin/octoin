#include "../../../../../src/gui/opengl/qtriangulatingstroker_p.h"
