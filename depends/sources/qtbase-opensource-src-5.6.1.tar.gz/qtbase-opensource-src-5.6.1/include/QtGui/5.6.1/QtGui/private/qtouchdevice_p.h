#include "../../../../../src/gui/kernel/qtouchdevice_p.h"
