#include "../../../../../src/gui/painting/qvectorpath_p.h"
