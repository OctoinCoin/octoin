#include "../../../../../src/gui/painting/qmath_p.h"
