#include "../../../../../src/gui/kernel/qplatformintegrationplugin.h"
