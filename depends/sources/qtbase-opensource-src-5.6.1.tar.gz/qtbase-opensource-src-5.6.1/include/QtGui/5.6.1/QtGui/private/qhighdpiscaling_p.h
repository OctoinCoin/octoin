#include "../../../../../src/gui/kernel/qhighdpiscaling_p.h"
