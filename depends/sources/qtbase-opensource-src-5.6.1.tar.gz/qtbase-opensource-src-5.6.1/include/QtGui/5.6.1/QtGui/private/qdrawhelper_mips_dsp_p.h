#include "../../../../../src/gui/painting/qdrawhelper_mips_dsp_p.h"
