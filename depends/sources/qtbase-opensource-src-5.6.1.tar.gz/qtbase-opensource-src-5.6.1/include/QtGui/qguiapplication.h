#include "../../src/gui/kernel/qguiapplication.h"
