#include "../../src/gui/painting/qpagesize.h"
