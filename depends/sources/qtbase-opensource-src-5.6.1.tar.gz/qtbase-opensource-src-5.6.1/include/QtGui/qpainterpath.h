#include "../../src/gui/painting/qpainterpath.h"
