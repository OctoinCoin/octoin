#include "../../src/gui/opengl/qopenglfunctions_4_2_compatibility.h"
