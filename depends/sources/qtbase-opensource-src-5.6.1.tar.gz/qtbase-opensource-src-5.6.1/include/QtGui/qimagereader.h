#include "../../src/gui/image/qimagereader.h"
