#include "../../src/gui/painting/qpainter.h"
