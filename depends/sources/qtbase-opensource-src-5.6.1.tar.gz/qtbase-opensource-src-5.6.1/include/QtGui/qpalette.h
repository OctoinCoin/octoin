#include "../../src/gui/kernel/qpalette.h"
