#include "../../src/sql/models/qsqlrelationaldelegate.h"
