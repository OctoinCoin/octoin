#include "../../src/concurrent/qtconcurrentmapkernel.h"
