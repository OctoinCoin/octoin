#include "../../src/concurrent/qtconcurrentfunctionwrappers.h"
