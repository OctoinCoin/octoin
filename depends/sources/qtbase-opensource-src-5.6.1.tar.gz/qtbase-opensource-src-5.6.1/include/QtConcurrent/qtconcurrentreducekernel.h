#include "../../src/concurrent/qtconcurrentreducekernel.h"
