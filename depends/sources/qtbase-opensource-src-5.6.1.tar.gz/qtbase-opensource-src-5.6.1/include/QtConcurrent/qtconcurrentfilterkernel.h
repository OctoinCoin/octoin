#include "../../src/concurrent/qtconcurrentfilterkernel.h"
