#include "../../src/concurrent/qtconcurrentstoredfunctioncall.h"
