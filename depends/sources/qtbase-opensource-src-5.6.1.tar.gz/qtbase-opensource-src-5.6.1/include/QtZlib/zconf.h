#include "../../src/3rdparty/zlib/zconf.h"
